package com.example.safezone.ebook;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;

public class College extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_college);
    }

    public void FirstYear(View view)
    {
        Intent intent= new Intent(College.this,FirstYear.class);
        startActivity(intent);
    }

    public void SecondYear(View view)
    {
        Intent intent = new Intent(College.this,SecondYear.class);
        startActivity(intent);
    }
}
