package com.example.safezone.ebook;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Toast;

public class Registration extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_registration);
    }


    public void Go(View view)
    {
        Intent intent = new Intent(Registration.this,MainActivity.class);
        startActivity(intent);
    }

    public void Done(View view)
    {
        Toast.makeText(Registration.this, "Registration is Completed", Toast.LENGTH_SHORT).show();
    }
}
