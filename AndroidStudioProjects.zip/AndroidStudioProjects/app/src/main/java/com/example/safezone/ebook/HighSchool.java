package com.example.safezone.ebook;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class HighSchool extends AppCompatActivity {

    private Button button1,button2,button3,button4,button5;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_high_school);

        button1 = findViewById(R.id.ClassSixid);
        button1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent one = new Intent(HighSchool.this,ClassOne.class);
                startActivity(one);
            }
        });
        button2 = findViewById(R.id.ClassSevenid);
        button2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent one = new Intent(HighSchool.this,ClassOne.class);
                startActivity(one);
            }
        });
        button3 = findViewById(R.id.ClassEightid);
        button3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent one = new Intent(HighSchool.this,ClassOne.class);
                startActivity(one);
            }
        });
        button4 = findViewById(R.id.ClassNineid);
        button4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent one = new Intent(HighSchool.this,ClassOne.class);
                startActivity(one);
            }
        });
        button5 = findViewById(R.id.ClassTenid);
        button5.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent one = new Intent(HighSchool.this,ClassOne.class);
                startActivity(one);
            }
        });
    }

    public void WebSitePrimary(View view)
    {
        Intent intent = new Intent(HighSchool.this,WebHighSchool.class);
        startActivity(intent);
    }
}
