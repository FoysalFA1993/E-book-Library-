package com.example.safezone.ebook;


import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;


public class MainActivity extends AppCompatActivity {



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }

    public void primary(View view)
    {
        Intent intent = new Intent(MainActivity.this,PrimarySchool.class);
        startActivity(intent);
    }

    public void high(View view)
    {
        Intent intent = new Intent(MainActivity.this,HighSchool.class);
        startActivity(intent);
    }

    public void college(View view)
    {
        Intent intent = new Intent(MainActivity.this,College.class);
        startActivity(intent);
    }

    public void university(View view)
    {
        Intent intent = new Intent(MainActivity.this,University.class);
        startActivity(intent);
    }

    public void Medical(View view)
    {
        Intent intent = new Intent(MainActivity.this,Medical.class);
        startActivity(intent);
    }

    public void Engineering(View view)
    {
        Intent intent = new Intent(MainActivity.this,Engineering.class);
        startActivity(intent);
    }
}





