package com.example.safezone.ebook;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;

import com.github.barteksc.pdfviewer.PDFView;

public class ClassOne extends AppCompatActivity {

    PDFView one ;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_class_one);

        one = (PDFView) findViewById(R.id.pdfOneid);
        one.fromAsset("android.pdf").load();

    }
}
